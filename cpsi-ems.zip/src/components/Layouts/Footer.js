import React, { Component } from "react";

class Footer extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div className="footer"> <p> Developed By: Dhaval Shah</p></div>
  }
}

export default Footer;